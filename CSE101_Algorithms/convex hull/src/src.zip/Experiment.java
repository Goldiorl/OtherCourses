
/**
 * Main class to start the program.
 * @author Rana
 *
 */
public class Experiment {

	public static void main(String[] args)
	{
		Execution execution = new Execution();
		execution.start(args);
	}
}
